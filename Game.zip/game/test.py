import pygame
import sys

pygame.init()
scr = pygame.display.set_mode((736, 552))
pygame.display.set_caption("Dungeons and Dragons")
icon = pygame.image.load('foto/icon/Avatar.jpg')
pygame.display.set_icon(icon)
bg_music = pygame.mixer.Sound('Music/nejnoe-spokoynoe-bezmyatejnoe-raznogolosoe-penie-ptits-v-lesu.mp3')
bg_music.play()
# Шрифти
font = pygame.font.SysFont('arial', 40)

# Кольори
WHITE = (255, 255, 255)

# Задній фон
background = pygame.image.load('foto/Background_Tutorial.jpg')


# Зображення кнопок
btn_play = pygame.image.load('foto/batton/image.png').convert_alpha()
btn_exit = pygame.image.load('foto/batton/imageQuti.png').convert_alpha()

# Функція для масштабованої анімованої кнопки
def draw_animated_button(image, x, y, scale_hover=1.1, action=None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    button_rect = image.get_rect(topleft=(x, y))
    if button_rect.collidepoint(mouse):
        # Збільшити зображення
        w, h = image.get_size()
        new_size = (int(w * scale_hover), int(h * scale_hover))
        scaled_img = pygame.transform.smoothscale(image, new_size)
        new_rect = scaled_img.get_rect(center=button_rect.center)
        scr.blit(scaled_img, new_rect.topleft)

        if click[0] == 1 and action:
            pygame.time.delay(200)
            action()
    else:
        scr.blit(image, (x, y))

# Сцена гри
def scene1():
    running = True
    while running:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        scr.fill((0, 0, 0))
        msg = font.render("Тут починається гра!", True, WHITE)
        scr.blit(msg, (200, 250))
        pygame.display.update()
        bg_music.stop()
        
       
# Головне меню
def main_menu():
    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        scr.blit(background, (0, 0))

        draw_animated_button(btn_play, 310, 150, action=scene1)
        draw_animated_button(btn_exit, 310, 270, action=pygame.quit)

        pygame.display.update()

main_menu()


